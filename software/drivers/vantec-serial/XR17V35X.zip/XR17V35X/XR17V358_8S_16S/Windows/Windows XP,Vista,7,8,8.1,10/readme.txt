11/11/14

5.1.0.0 version of the Windows 2000/XP/Vista/7/8/8.1 driver has support for XR17C15x/XR17D15x/XR17V25x/XR17V35x PCI/PCIe cards.
For the XR17C15x, XR17D15x and XR17V25x devices, the driver assumes a clock frequency of 14.7456 MHz.

Contents:

	xr17v35x_win_5100_x64_signed =	Folder containing the HCK-certified 64-bit drivers. COM port number will start at the next available COM port.  
	xr17v35x_win_5100_x86_signed =  Folder containing the HCK-certified 32-bit drivers. COM port number will start at the next available COM port.



Driver Revision History
=================================
From 2.5.0.0 to 5.1.0.0: Combined driver for Windows 2000/XP with Windows Vista/7/8/8.1. Added support for accessing MPIO registers separately without opening the first COM port. Added support for configuring the modes on the XR17V358/SP339-0A-EVB PCIe UART eval board. Restoring UART and MPIO registers after waking up from sleep/hibernate.  Added support for baud rates lesss than 300 bps for the PCIe UART.  Minor bug fixes to pass WHQL/HCK testing.

From 2.4.0.0 to 2.5.0.0: Restoring of additional UART settings (that are set by properties page like RS485 and trigger levels) while resuming from standby/hibernate if the port was opened in the application while going to standby.

From 2.3.0.0 to 2.4.0.0: Fixed multiple PCI/PCIe cards support issue. Fixed NextFreePort driver sequencing issue. Fixed some data-lock and CloseHandle issues. Fixed serial mouse failure. Optimized interrupt servicing to improve data throughput. 8X sampling mode enabled by default for PCI UARTs (XR17x15x and XR17V25x). Added coinstaller to support matching COM names in the Device Manager.

From 2.2.0.0 to 2.3.0.0: Fixed RS-485 mode polarity bug in properties page.  Added support for selecting TX/RX trigger levels from properties page.  Fixed bug with serial modems.
From 2.1.0.0 to 2.2.0.0: Added support for enabling Auto RS-485 mode from properties page. Included signed WHQL driver for 64-bit OS.




If you have any questions, please contact uarttechsupport@exar.com.