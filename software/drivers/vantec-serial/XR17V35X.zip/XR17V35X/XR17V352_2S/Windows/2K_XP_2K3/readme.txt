7/10/2012

4.3.0.0 version of Windows Xp/2000 driver has support for xr17c15x/xr17v25x/xr17v35x PCI/PCIe cards.

Contents:

	x86 = Folder containing the signed WHQL (The signed driver is the �NextFree_14.7� version) and unsigned 32-bit driver .
		Signed = Folder containing the signed WHQL 32-bit "NextFree_14.7" version drivers.
		unsigned = Folder containing the unsigned 32-bit drivers.
			
			The unsigned folder contains the following sub-folders:

			COM3_14.7 = 	Folder containing driver object files that have been hardcoded to start at COM3 and using a 14.7456MHz clock/crystal.
			COM3_24 = 	Folder containing driver object files that have been hardcoded to start at COM3 and using a 24MHz clock/crystal.
			COM5_14.7 = 	Folder containing driver object files that have been hardcoded to start at COM5 and using a 14.7456MHz clock/crystal.
			COM5_24 = 	Folder containing driver object files that have been hardcoded to start at COM5 and using a 24MHz clock/crystal.
			NextFree_14.7 =	Folder containing driver object files that will assign the next available port number to the PCI/PCIe UART channels and using a 14.7456MHz clock/crystal.				
			NextFree_24 =	Folder containing driver object files that will assign the next available port number to the PCI/PCIe UART channels and using a 24MHz clock/crystal.


	x64 = Folder containing the unsigned 64-bit drivers
		unsigned = Folder containing the unsigned 64-bit drivers

			The unsigned folder contains the following sub-folders:

			COM3_14.7 = 	Folder containing driver object files that have been hardcoded to start at COM3 and using a 14.7456MHz clock/crystal.
			COM3_24 = 	Folder containing driver object files that have been hardcoded to start at COM3 and using a 24MHz clock/crystal.
			COM5_14.7 = 	Folder containing driver object files that have been hardcoded to start at COM5 and using a 14.7456MHz clock/crystal.
			COM5_24 = 	Folder containing driver object files that have been hardcoded to start at COM5 and using a 24MHz clock/crystal.
			NextFree_14.7 =	Folder containing driver object files that will assign the next available port number to the PCI/PCIe UART channels and using a 14.7456MHz clock/crystal.						
			NextFree_24 =	Folder containing driver object files that will assign the next available port number to the PCI/PCIe UART channels and using a 24MHz clock/crystal.	

Note: The crystal/clock frequency applies to the PCI UARTs only



						
Driver Revision History
=================================
From 4.2.0.0 to 4.3.0.0: Restoring of additional UART settings (that are set by properties page like RS485 and trigger levels) while resuming from standby/hibernate if the port was opened in the application while going to standby.

From 4.1.0.0 to 4.2.0.0: Enabled 8x mode for xr17c15x devices. Fixed serial mouse failure (Sometimes rxfifo -trigger reg could be set to 0 when mouse is connected and that was causing serial mouse to fail. Now we make sure it is 1 and above). Fixed the bug in ISR logic (fail to service ports of different boards when multiple cards were present in the system). Implemented burst reads and burst writes logic for throughput efficiency.

From 4.0.0.0 to 4.1.0.0: Added support for enabling Auto RS-485 mode and selecting TX/RX trigger levels from properties page.  Fixed bug with serial modems.

From 3.8.0.0 to 4.0.0.0: Added support for PCIe UARTs.


For any questions, please contact uarttechsupport@exar.com.