7/10/2012

2.5.0.0 version of Windows Vista/7 driver has support for xr17c15x/xr17v25x/xr17v35x PCI/PCIe cards.

Contents:

	x86 =	Folder containing the signed WHQL and unsigned 32-bit drivers.

		Signed = Folder containing the signed WHQL 32-bit "NextFreePort_14.7" version driver
		Unsigned = Folder containing the unsigned 32-bit driver 

		The unsigned folder in the x86 folder above contains the following sub-folders:

		COM3_14.7 = 	Folder containing driver object files that have been hardcoded to start at COM3 and using a 14.7456MHz clock/crystal.
		COM3_24 = 	Folder containing driver object files that have been hardcoded to start at COM3 and using a 24MHz clock/crystal.
		COM5_14.7 = 	Folder containing driver object files that have been hardcoded to start at COM5 and using a 14.7456MHz clock/crystal.
		COM5_24 = 	Folder containing driver object files that have been hardcoded to start at COM5 and using a 24MHz clock/crystal.
		NextFree_14.7 =	Folder containing driver object files that will assign the next available port number to the PCI/PCIe UART channels and using a 14.7456MHz clock/crystal.						
		NextFree_24 =	Folder containing driver object files that will assign the next available port number to the PCI/PCIe UART channels and using a 24MHz clock/crystal.						
				
Note: The crystal/clock frequency applies to the PCI UARTs only	

		
	x64 =	Folder containing the signed WHQL 64-bit driver. 

		Signed = Folder containing the signed WHQL 64-bit "NextFreePort_14.7" version driver

		


Driver Revision History
=================================
From 2.4.0.0 to 2.5.0.0: Restoring of additional UART settings (that are set by properties page like RS485 and trigger levels) while resuming from standby/hibernate if the port was opened in the application while going to standby.

From 2.3.0.0 to 2.4.0.0: Fixed multiple PCI/PCIe cards support issue. Fixed NextFreePort driver sequencing issue. Fixed some data-lock and CloseHandle issues. Fixed serial mouse failure. Optimized interrupt servicing to improve data throughput. 8X sampling mode enabled by default for PCI UARTs (XR17x15x and XR17V25x). Added coinstaller to support matching COM names in the Device Manager.

From 2.2.0.0 to 2.3.0.0: Fixed RS-485 mode polarity bug in properties page.  Added support for selecting TX/RX trigger levels from properties page.  Fixed bug with serial modems.
From 2.1.0.0 to 2.2.0.0: Added support for enabling Auto RS-485 mode from properties page. Included signed WHQL driver for 64-bit OS.




If you have any questions, please contact uarttechsupport@exar.com.